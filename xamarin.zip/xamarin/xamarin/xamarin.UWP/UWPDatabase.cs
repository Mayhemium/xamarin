﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.Storage;

namespace xamarin.UWP
{
        class DatabaseConnectionUWP : IDatabaseConnection
        {
            public string DbConnection()
            {
                var dbName = "userDb.db3";
                var path = Path.Combine(ApplicationData.Current.LocalFolder.Path, dbName);
                return path;
            }
        }
    
}
