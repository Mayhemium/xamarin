﻿using System;
using System.Collections.Generic;
using System.Text;

namespace xamarin
{
    public interface IDatabaseConnection
    {
        string DbConnection();
    }
}
