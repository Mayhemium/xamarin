﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace xamarin
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class EditPage : ContentPage
    {
        UserDatabase db;
        User user;
        public EditPage(UserDatabase db, User user)
        {
            InitializeComponent();
            this.db = db;
            this.user = user;

            name.Text = user.Name;
            surname.Text = user.Surname;
            email.Text = user.Email;
        }

        private void Button_Clicked(object sender, EventArgs e)
        {
            user.Name = name.Text;
            user.Surname = surname.Text;
            user.Email = email.Text;
            db.UpdateUser(user);
            Navigation.PopAsync();
        }
    }
}