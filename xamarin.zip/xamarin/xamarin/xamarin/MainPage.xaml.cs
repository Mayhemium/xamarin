﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace xamarin
{
    // Learn more about making custom code visible in the Xamarin.Forms previewer
    // by visiting https://aka.ms/xamarinforms-previewer
    [DesignTimeVisible(false)]
    public partial class MainPage : ContentPage
    {
        UserDatabase db = new UserDatabase();
        public MainPage()
        {
            InitializeComponent();

            myList.ItemsSource = db.Users;
        }

        private async void Button_Clicked(object sender, EventArgs e)
        {
            await Navigation.PushAsync(new AddPage(db));
        }

        private async void TextCell_Tapped(object sender, EventArgs e)
        {
            ViewCell vc = sender as ViewCell;
            await Navigation.PushAsync(new EditPage(db, vc.BindingContext as User));
        }

        private void Button_Clicked_1(object sender, EventArgs e)
        {
            Button btn = sender as Button;
            db.RemoveUser(btn.Parent.BindingContext as User);
        }
    }
}
