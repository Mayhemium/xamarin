﻿using SQLite;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Text;

namespace xamarin
{
    
        [Table("users")]
        public class User : INotifyPropertyChanged
        {
            private int _id;
            [PrimaryKey, AutoIncrement]

            public int Id
            {
                get
                {
                    return _id;
                }
                set
                {
                    this._id = value;
                    OnPropertyChanged(nameof(Id));
                }
            }



            private string _name;


            public string Name
            {
                get
                {
                    return _name;
                }
                set
                {
                    this._name = value;
                    OnPropertyChanged(nameof(Name));
                }
            }

            private string _surname;


            public string Surname
            {
                get
                {
                    return _surname;
                }
                set
                {
                    this._surname = value;
                    OnPropertyChanged(nameof(Surname));
                }
            }

            private string _email;


            public string Email
            {
                get
                {
                    return _email;
                }
                set
                {
                    this._email = value;
                    OnPropertyChanged(nameof(Email));
                }
            }

            public event PropertyChangedEventHandler PropertyChanged;

            private void OnPropertyChanged(string propertyName)
            {
                this.PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    
}
