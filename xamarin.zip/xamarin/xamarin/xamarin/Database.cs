﻿using SQLite;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;
using Xamarin.Forms;

namespace xamarin
{
    public class UserDatabase
    {
        private SQLiteConnection database;
        private static object collisionLock = new object();

        public ObservableCollection<User> Users { get; set; }

        public UserDatabase()
        {
            database = new SQLiteConnection(DependencyService.Get<IDatabaseConnection>().DbConnection());
            database?.CreateTable<User>();
            Users = new ObservableCollection<User>(database.Table<User>());
            if (database.Table<User>().Count() == 0)
            {
                CreateData();
            }
        }

        private void CreateData()
        {
            Users.Clear();
            Users.Add(new User()
            {
                Name = "first",
                Surname = "first",
                Email = "first@first.pl"
            });
            Users.Add(new User()
            {
                Name = "second",
                Surname = "second",
                Email = "second@second.pl"
            });
            lock (collisionLock)
            {
                database.Insert(Users[0]);
            }
        }

        public void AddUser(User user)
        {
            Users.Add(user);
            database.Insert(user);
        }
        public void RemoveUser(User user)
        {
            Users.Remove(user);
            database.Delete(user);
        }
        public void UpdateUser(User user)
        {
            Users.Remove(user);
            Users.Add(user);
            database.Update(user);
        }
    }
}
