﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace xamarin
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class AddPage : ContentPage
    {
        UserDatabase db;
        public AddPage(UserDatabase db)
        {
            InitializeComponent();
            this.db = db;

        }

        private void Button_Clicked(object sender, EventArgs e)
        {
            db.AddUser(new User() { Name = name.Text, Surname =surname.Text, Email=email.Text});
            Navigation.PopAsync();
        }
    }
}