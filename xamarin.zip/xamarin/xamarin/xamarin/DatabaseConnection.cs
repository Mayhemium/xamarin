﻿using SQLite;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace xamarin
{
    class DatabaseConnection
    {
        public string DbConnection()
        {
            var dbName = "WinDb.db3";
            var path = Path.Combine(System.Environment.GetFolderPath(System.Environment.SpecialFolder.Personal), dbName);
            return path;
        }
    }
}
